/*
 * @author: Simran Singh ( simran.singh2198@gmail.com )
 */
$(function () {
    $("#toggler").click(function () {
        $(".list-container").toggleClass("list-toggler");
    });
});